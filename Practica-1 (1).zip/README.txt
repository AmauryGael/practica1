Mostrar mensaje de los siguintes nombres"Brandon","Sergio","Arturo","Kevin","Alan","Amaro","Max","Luna","Miguel","Angel";
Moatrar el mensaje del elemento